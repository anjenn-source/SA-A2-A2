package com.example.project136.Activities

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.project136.Domains.PopularDomain
import com.example.project136.R

class DetailActivity : AppCompatActivity() {
    private var titleTxt: TextView? = null
    private var locationTxt: TextView? = null
    private var bedTxt: TextView? = null
    private var guideTxt: TextView? = null
    private var wifiTxt: TextView? = null
    private var descriptionTxt: TextView? = null
    private var scoreTxt: TextView? = null
    private var item: PopularDomain? = null
    private var picImg: ImageView? = null
    private var backBtn: ImageView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        initView()
        setVariable()
    }

    private fun setVariable() {
        item = intent.getSerializableExtra("object") as PopularDomain?
        titleTxt!!.text = item!!.title
        scoreTxt!!.text = "" + item!!.score
        locationTxt!!.text = item!!.location
        bedTxt!!.text = item!!.bed.toString() + " Bed"
        descriptionTxt!!.text = item!!.description
        if (item!!.isGuide) {
            guideTxt!!.text = "Guide"
        } else {
            guideTxt!!.text = "No-Guide"
        }
        if (item!!.isWifi) {
            wifiTxt!!.text = "Wifi"
        } else {
            wifiTxt!!.text = "No-Wifi"
        }
        val drawableResId = getResources().getIdentifier(item!!.pic, "drawable", packageName)
        Glide.with(this)
            .load(drawableResId)
            .into(picImg!!)
        backBtn!!.setOnClickListener { v: View? -> finish() }
    }

    private fun initView() {
        titleTxt = findViewById(R.id.titleTxt)
        locationTxt = findViewById(R.id.locationTxt)
        bedTxt = findViewById(R.id.bedTxt)
        guideTxt = findViewById(R.id.guideTxt)
        wifiTxt = findViewById(R.id.wifiTxt)
        descriptionTxt = findViewById(R.id.descriptionTxt)
        scoreTxt = findViewById(R.id.scoreTxt)
        picImg = findViewById(R.id.picImg)
        scoreTxt = findViewById(R.id.scoreTxt)
        backBtn = findViewById(R.id.backBtn)
    }
}