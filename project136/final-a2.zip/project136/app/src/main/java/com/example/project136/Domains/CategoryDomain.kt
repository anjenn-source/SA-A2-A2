package com.example.project136.Domains

class CategoryDomain(var title: String, var picPath: String)
